# tiantianshengxian
天天生鲜前段网页
天天生鲜前段页面完成
注：导航栏中的登录使用的是Ajax_4.6.0做的后台服务器进行json请求